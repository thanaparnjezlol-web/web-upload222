# Agent Distribution Website

This repository contains the static website for distributing the agent binary as part of a university final-year project.

## Purpose

This website serves as a distribution point for the agent binary, which is designed to be installed on client machines as part of a distributed system architecture. The site provides a simple, secure interface for users to download the appropriate agent binary for their operating system.

## Architecture

- **Hosting**: Cloudflare Pages
- **Domain**: agent.jezlol.xyz
- **Type**: Static website (no server-side processing)
- **Authentication**: None required (public distribution)

## Structure

```
.
├── index.html              # Main download page
├── checksums.txt           # SHA-256 checksums for verification
├── robots.txt              # Search engine directives
├── README.md               # This file
└── .well-known/
    └── security.txt        # Security contact information
```

## Distribution Process

1. Agent binaries are built and uploaded to the repository or Cloudflare Pages deployment
2. Checksums are generated and updated in `checksums.txt`
3. The static site is deployed via Cloudflare Pages
4. Users access the site and download the appropriate binary for their platform
5. Users verify the downloaded file against the published checksums before installation

## File Descriptions

### index.html
The main landing page that provides:
- Overview of the agent's purpose
- Download links for Windows and Linux platforms
- Security warnings about checksum verification
- Installation instructions

### checksums.txt
Contains SHA-256 checksums for all distributed binaries. Format:
```
SHA256(agent-windows-amd64.exe)= <checksum>
SHA256(agent-linux-amd64)= <checksum>
```

### robots.txt
Directives for web crawlers. Currently allows all crawlers to index the site.

### security.txt
Located at `/.well-known/security.txt`, this file provides security contact information following [RFC 9116](https://www.rfc-editor.org/rfc/rfc9116.html).

## Deployment

This site is deployed automatically via Cloudflare Pages:

1. Push changes to the repository
2. Cloudflare Pages detects the changes
3. The static site is built and deployed (no build step required)
4. The site is available at agent.jezlol.xyz

## Security Considerations

- All downloads should be verified against published checksums
- The site uses HTTPS (enforced by Cloudflare)
- No user authentication is required (public distribution)
- Security contact information is available via security.txt
- No secrets or sensitive data are stored in this repository

## Maintenance

To update the site:
1. Modify the relevant files (HTML, checksums, etc.)
2. Commit and push changes
3. Cloudflare Pages will automatically redeploy

To add new agent binaries:
1. Add the binary file to the repository
2. Generate and update checksums in `checksums.txt`
3. Update `index.html` if new platforms are added
4. Commit and push changes

## Academic Context

This project is part of a university final-year project focusing on distributed systems architecture. The agent distribution mechanism demonstrates practical considerations for software deployment, security, and user experience in production environments.

## License

This distribution website is part of an academic project. Please refer to the project documentation for licensing information.
